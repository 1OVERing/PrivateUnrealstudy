﻿#pragma once
class $safeitemname$
{
private: // Member Variable
public: // Member Function


public: // operator overLoading
	$safeitemname$& operator=(const $safeitemname$& p) = delete; // 복사 이동 연산자 선언    
	$safeitemname$& operator=($safeitemname$&& p) noexcept = delete; // 이동 복사 연산자 선언   
public: // constructor / destructor
	$safeitemname$();
	~$safeitemname$();
	$safeitemname$(const $safeitemname$& other) = delete;
	$safeitemname$(const $safeitemname$&& other) noexcept = delete;
};